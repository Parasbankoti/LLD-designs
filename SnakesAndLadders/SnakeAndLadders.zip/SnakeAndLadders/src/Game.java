import java.util.*;

public class Game {
    List<Snake> snakeList = new ArrayList<>();
    List<Ladder> ladderList = new ArrayList<>();
    Queue<Players> playersQueue = new LinkedList<>();


    public void InitializeGame(){

        Scanner sc = new Scanner(System.in);
        int noOfSnakes = sc.nextInt();

        for(int i=0;i<noOfSnakes;i++){
            int head= sc.nextInt();;
            int tail = sc.nextInt();
            Snake snake = new Snake(head,tail);
            snakeList.add(snake);
        }
        int noOfLadders = sc.nextInt();
        for(int i=0;i<noOfLadders;i++){
            int head= sc.nextInt();;
            int tail = sc.nextInt();
            Ladder ladder = new Ladder(tail,head);
            ladderList.add(ladder);
        }



        int numberOfPlayers = sc.nextInt();
        for (int i = 0; i < numberOfPlayers; i++) {
            String name = sc.next();
            Players currPlayer = new Players(name);
            playersQueue.add(currPlayer);
        }

        System.out.println("game is initialized...");
    }

    public void viewLadderList(){
        for(Ladder l:ladderList){
            System.out.println(l.getTail() + "to " + l.getHead());
        }
    }
    public void viewSnakeList(){
        for(Snake s:snakeList){
            System.out.println(s.getHead() + "to " + s.getTail());
        }
    }

    public void startGame(){
        boolean gameEnded = false;
       while(!gameEnded){
           Players currPlayer = playersQueue.poll();
           Snake snake=new Snake();
           Ladder ladder=new Ladder();
           int currPlayerCurrentPosition = currPlayer.getCurrPosition();
           int diceNumber = Dice.RollDice();

           int currPlayerNewPosition = currPlayerCurrentPosition + diceNumber;

           while(snake.isSnakeHead(currPlayerNewPosition,snakeList) || ladder.isLadderTail(currPlayerNewPosition,ladderList)){

               if(snake.isSnakeHead(currPlayerNewPosition,snakeList)){
                   currPlayerNewPosition = snake.getTailPosition(currPlayerNewPosition,snakeList);
               }
               if(ladder.isLadderTail(currPlayerNewPosition,ladderList)){
                   currPlayerNewPosition = ladder.getHeadPosition(currPlayerNewPosition,ladderList);
               }

           }
           System.out.println(currPlayer.getPlayerName() + " rolled a "+ diceNumber + " and moved from "+ currPlayerCurrentPosition + " to " + currPlayerNewPosition );

           if(currPlayerNewPosition == 100){
               System.out.println(currPlayer.getPlayerName() + "wins !!!");
               gameEnded=true;
               break;
           }

           if(currPlayerNewPosition >100){
               playersQueue.add(currPlayer);
               continue;
           }
           else{
               currPlayer.setCurrPosition(currPlayerNewPosition);
               playersQueue.add(currPlayer);
           }
        }
    }



}
