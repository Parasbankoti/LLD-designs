public class Players {
    public void setCurrPosition(int currPosition) {
        this.currPosition = currPosition;
    }

    public String getPlayerName() {
        return playerName;
    }

    public int getCurrPosition() {
        return currPosition;
    }

    private int currPosition;
    private String playerName;

    Players(String name){
        playerName = name;
        this.currPosition=0;
    }
}
