import java.util.List;

public class Ladder {
    private int head;
    private int tail;

    public void setHead(int head) {
        this.head = head;
    }

    public void setTail(int tail) {
        this.tail = tail;
    }

    public int getHead() {
        return head;
    }

    public int getTail() {
        return tail;
    }

    Ladder(int head, int tail){
        this.head=head;
        this.tail=tail;
    }
    Ladder(){}

    public boolean isLadderTail(int currPlayerNewPosition, List<Ladder> ladderList) {
        for(Ladder l:ladderList){
            if(currPlayerNewPosition == l.tail){
                return true;
            }
        }
        return false;
    }

    public int getHeadPosition(int currPlayerNewPosition, List<Ladder> ladderList) {
        for(Ladder l :ladderList){
            if(currPlayerNewPosition == l.tail){
                return l.head;
            }
        }
        return -1;

    }
}
