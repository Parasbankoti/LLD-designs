import java.util.List;

public class Snake {
    private int head;
    private int tail;

    public int getHead() {
        return head;
    }

    public void setHead(int head) {
        this.head = head;
    }

    public int getTail() {
        return tail;
    }

    public void setTail(int tail) {
        this.tail = tail;
    }

    Snake(int head, int tail){
        this.head=head;
        this.tail=tail;
    }
    Snake(){

    }

    public  boolean isSnakeHead(int currPlayerNewPosition, List<Snake> snakeList) {
        for (Snake i:snakeList) {
            if(currPlayerNewPosition == i.head){
                return true;
            }
        }
        return false;
    }

    public  int getTailPosition(int currPlayerNewPosition, List<Snake> snakeList) {
        for(Snake i:snakeList){
            if(currPlayerNewPosition == i.head)
                return i.tail;
        }
        return -1;
    }


}
